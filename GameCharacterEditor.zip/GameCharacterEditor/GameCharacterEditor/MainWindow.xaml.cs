﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Threading;
using MongoDB.Driver;

namespace GameCharacterEditor
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private List<Unit> unitLst = new List<Unit>();
        private double str = 0;
        private double intel = 0;
        private double dex = 0;
        private double cons = 0;
        private double extra;
        private int maxExp = 1000;
        private int currentExp = 0;
        private int x = 0;

        public MainWindow()
        {
            InitializeComponent();
            
            BtnAdd.Visibility = Visibility.Hidden;
            unitLst = Unit.TakeList();
            GetUnitInfo(x);
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                unitLst[x].PhysAttack();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"{unitLst[x].Name} {ex.Message}");
            }
            GetUnitInfo(x);
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            try
            {
                unitLst[x].PhysDefence();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"{unitLst[x].Name} {ex.Message}");
            }
            GetUnitInfo(x);
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            try
            {
                unitLst[x].MagicAttack();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"{unitLst[x].Name} {ex.Message}");
            }
            GetUnitInfo(x);
        }

        private void Button_Click_8(object sender, RoutedEventArgs e)
        {
            try
            {
                unitLst[x].MagicDefence();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"{unitLst[x].Name} {ex.Message}");
            }
            GetUnitInfo(x);
        }


        private void ComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            switch (cmbbox.SelectedIndex)
            {
                case 0:
                    Warrior warior = new Warrior();
                    GetUnitInfo(warior);
                    BtnAdd.Visibility = Visibility.Visible;
                    maxExp = 1000;
                    currentExp = 0;
                    break;
                case 1:
                    Rogue rogue = new Rogue(); 
                    GetUnitInfo(rogue);
                    maxExp = 1000;
                    BtnAdd.Visibility = Visibility.Visible;
                    currentExp = 0;
                    break;
                case 2:
                    Sorcerer sorcerer = new Sorcerer();
                    GetUnitInfo(sorcerer);
                    BtnAdd.Visibility = Visibility.Visible;
                    maxExp = 1000;
                    currentExp = 0;
                    break;
            }
        }

        private void GetUnitInfo(int index)
        {
            try
            {
                txthp.Text = unitLst[index].Hp.ToString();
                txtName.Text = unitLst[index].Name.ToString();
                txtExtra.Text = unitLst[index].Extra.ToString();
                txtStrength.Text = unitLst[index].Strength.ToString();
                txtDexterity.Text = unitLst[index].Dexterity.ToString();
                txtIntelegence.Text = unitLst[index].Intelegence.ToString();
                txtConstitution.Text = unitLst[index].Constitution.ToString();
                txtExp.Text = unitLst[index].Experience.ToString();
                txtLvl.Text = unitLst[index].Lvl.ToString();
                extra = double.Parse(txtExtra.Text);
                cons = unitLst[x].Cons;
                intel = unitLst[x].Intel;
                dex = unitLst[x].Dex;
                str = unitLst[x].Str;
                extra = unitLst[x].Extra;
                txtExtra.Text = extra.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void GetUnitInfo(Unit unit)
        {
            txthp.Text = unit.Hp.ToString();
            txtName.Text = unit.Name.ToString();
            txtExtra.Text = unit.Extra.ToString();
            txtStrength.Text = unit.Strength.ToString();
            txtDexterity.Text = unit.Dexterity.ToString();
            txtIntelegence.Text = unit.Intelegence.ToString();
            txtConstitution.Text = unit.Constitution.ToString();
            extra = double.Parse(txtExtra.Text);
            txtExp.Text = unit.Experience.ToString();
            txtLvl.Text = unit.Lvl.ToString();
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            switch (cmbbox.SelectedIndex)
            {
                case 0:
                    Warrior warrior = new Warrior(Double.Parse(txtStrength.Text), Double.Parse(txtDexterity.Text), Double.Parse(txtConstitution.Text), Double.Parse(txtIntelegence.Text), txtName.Text, int.Parse(txtLvl.Text));
                    Unit.Add(warrior);
                    MessageBox.Show($"Unit is created and added to database {warrior.Name}");
                    unitLst.Add(warrior);
                    x = unitLst.Count - 1;
                    GetUnitInfo(unitLst.Count - 1);
                    break;
                case 1:
                    Rogue rogue = new Rogue(Double.Parse(txtStrength.Text), Double.Parse(txtDexterity.Text), Double.Parse(txtConstitution.Text), Double.Parse(txtIntelegence.Text), txtName.Text, int.Parse(txtLvl.Text));
                    Unit.Add(rogue);
                    MessageBox.Show($"Unit is created and added to database {rogue.Name}");
                    
                    unitLst.Add(rogue);
                    x = unitLst.Count - 1;
                    GetUnitInfo(unitLst.Count - 1);
                    
                    break;
                case 2:
                    Sorcerer sorcerer = new Sorcerer(Double.Parse(txtStrength.Text), Double.Parse(txtDexterity.Text), Double.Parse(txtConstitution.Text), Double.Parse(txtIntelegence.Text), txtName.Text, int.Parse(txtLvl.Text));
                    Unit.Add(sorcerer);
                    MessageBox.Show($"Unit is created and added to database {sorcerer.Name}");
                    
                    unitLst.Add(sorcerer);
                    x = unitLst.Count - 1;
                    GetUnitInfo(unitLst.Count - 1);
                    
                    break;
            }
        }


        private void Next_Click(object sender, RoutedEventArgs e)
        {
            if (x + 1 <= unitLst.Count - 1)
            {
                x++;
            }
            else
            {
                x = 0;
            }
            GetUnitInfo(x);
            BtnAdd.Visibility = Visibility.Hidden;
            cmbbox.SelectedIndex = -1;
        }

        private void Prev_Click(object sender, RoutedEventArgs e)
        {
            if (x - 1 >= 0)
            {
                x--;
            }
            else
            {
                x = unitLst.Count - 1;
            }
            GetUnitInfo(x);
            BtnAdd.Visibility = Visibility.Hidden;
            cmbbox.SelectedIndex = -1;
        }

        private void Update()
        {
            try
            {
                MongoClient client = new MongoClient(); 
                IMongoDatabase db = client.GetDatabase("Units");
                IMongoCollection<Unit> data = db.GetCollection<Unit>("unit_collection");
                var UpdateDef = Builders<Unit>.Update.Set("Lvl", int.Parse(txtLvl.Text)).Set("Hp", double.Parse(txthp.Text))
                    .Set("Name", txtName.Text).Set("Extra", double.Parse(txtExtra.Text))
                    .Set("Strength", double.Parse(txtStrength.Text)).Set("Dexterity", double.Parse(txtDexterity.Text))
                    .Set("Intelegence", double.Parse(txtIntelegence.Text)).Set("Constitution", double.Parse(txtConstitution.Text))
                    .Set("PDefence", unitLst[x].PDefence).Set("MDefence", unitLst[x].MDefence).Set("PAttack", unitLst[x].PAttack)
                    .Set("MAttack", unitLst[x].MAttack).Set("Experience", double.Parse(txtExp.Text))
                    .Set("Cons", cons).Set("Dex", dex)
                    .Set("Str", str).Set("Intel", intel)
                    .Set("Extra", extra);
                data.UpdateOne(basa => basa._id == unitLst[x]._id, UpdateDef);
                unitLst = Unit.TakeList();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Не удалось обновить данные персонажа в базе\n" + ex.Message);
            }
        }

        private void GetExp(int k)
        {
            txtExp.Text = (int.Parse(txtExp.Text) + k).ToString();
            currentExp += k;
            if (currentExp >= maxExp && int.Parse(txtLvl.Text) < 9)
            {
                currentExp = maxExp;
                txtLvl.Text = (int.Parse(txtLvl.Text) + 1).ToString();
                maxExp = currentExp + 1000 * int.Parse(txtLvl.Text);
                LvlUpdate();
            }

        }

        private void Button_Click_7(object sender, RoutedEventArgs e)
        {
            if (extra > 0 && (int.Parse(txtStrength.Text) < unitLst[x].MaxStr))
            {
                txtStrength.Text = (int.Parse(txtStrength.Text) + 1).ToString();
                extra--;
                str++;
            }

            Refresh();
        }

        private void Button_Click_9(object sender, RoutedEventArgs e)
        {
            if (extra > 0 && (int.Parse(txtDexterity.Text) < unitLst[x].MaxDex))
            {
                txtDexterity.Text = (int.Parse(txtDexterity.Text) + 1).ToString();
                extra--;
                dex++;
            }
            Refresh();
        }

        private void Button_Click_10(object sender, RoutedEventArgs e)
        {
            if (extra > 0 && (int.Parse(txtIntelegence.Text) < unitLst[x].MaxIntel))
            {
                txtIntelegence.Text = (int.Parse(txtIntelegence.Text) + 1).ToString();
                extra--;
                intel++;
            }
            Refresh();
        }

        private void Button_Click_11(object sender, RoutedEventArgs e)
        {
            if (extra > 0 && (int.Parse(txtConstitution.Text) < unitLst[x].MaxCons))
            {
                txtConstitution.Text = (int.Parse(txtConstitution.Text) + 1).ToString();
                extra--;
                cons++;
            }
            Refresh();
        }

        private void Button_Click_12(object sender, RoutedEventArgs e) //
        {
            if (int.Parse(txtDexterity.Text) - 1 >= extra && dex > 0)
            {
                txtDexterity.Text = (int.Parse(txtDexterity.Text) - 1).ToString();
                extra++;
                dex--;
            }
            Refresh();
        }

        private void Button_Click_13(object sender, RoutedEventArgs e)
        {
            if (int.Parse(txtIntelegence.Text) - 1 >= extra && intel > 0)
            {
                txtIntelegence.Text = (int.Parse(txtIntelegence.Text) - 1).ToString();
                extra++;
                intel--;
            }
            Refresh();
        }

        private void Button_Click_14(object sender, RoutedEventArgs e)
        {
            if (int.Parse(txtConstitution.Text) - 1 >= extra && cons > 0)
            {
                txtConstitution.Text = (int.Parse(txtConstitution.Text) - 1).ToString();
                extra++;
                cons--;
            }
            Refresh();
        }

        private void Button_Click_15(object sender, RoutedEventArgs e)
        {
            if (int.Parse(txtStrength.Text) - 1 >= extra && str > 0)
            {
                txtStrength.Text = (int.Parse(txtStrength.Text) - 1).ToString();
                extra++;
                str--;
            }
            Refresh();
        }

        private void Refresh()
        {
            txthp.Text = (int.Parse(txtStrength.Text) * 5 + int.Parse(txtConstitution.Text) * 10).ToString();
            
            txtExtra.Text = extra.ToString(); // добавлен
            FillInfo();
          
        }

        private void FillInfo()
        {
            try
            {
                unitLst[x].Constitution = double.Parse(txtConstitution.Text);
                unitLst[x].Dexterity = double.Parse(txtDexterity.Text);
                unitLst[x].Intelegence = double.Parse(txtIntelegence.Text);
                unitLst[x].Strength = double.Parse(txtStrength.Text);
                unitLst[x].Experience = double.Parse(txtExp.Text);
                unitLst[x].Extra = double.Parse(txtExtra.Text);
                unitLst[x].Hp = double.Parse(txthp.Text);
                unitLst[x].Lvl = int.Parse(txtLvl.Text);
                unitLst[x].Cons = cons;
                unitLst[x].Dex = dex;
                unitLst[x].Intel = intel;
                unitLst[x].Str = str;
                unitLst[x].Name = txtName.Text;
                Update();
            }
            catch { }
        }

        private void Button_Click_4(object sender, RoutedEventArgs e)
        {
            if (int.Parse(txtLvl.Text) < 9 || !Check())
            {
                txtExp.Text = (int.Parse(txtExp.Text) + 500).ToString();
                currentExp += 500;
            }
        }

        private void LvlUpdate()
        {
            if (int.Parse(txtLvl.Text) > 1 && int.Parse(txtLvl.Text) < 9 && !Check())
            {
                txtConstitution.Text = (int.Parse(txtConstitution.Text) + 10).ToString();
                txtStrength.Text = (int.Parse(txtStrength.Text) + 10).ToString();
                txtDexterity.Text = (int.Parse(txtDexterity.Text) + 10).ToString();
                txtIntelegence.Text = (int.Parse(txtIntelegence.Text) + 10).ToString();
                txtExtra.Text = (int.Parse(txtExtra.Text) + 5).ToString();
                extra += 5;
                unitLst[x].Extra = extra;
                Refresh();
            }
            else if (int.Parse(txtLvl.Text) > 1 || Check())
            {
                MessageBox.Show("Достигнут максимальный уровень");
                btnAddExp500.Visibility = Visibility.Hidden;
                btnAddExp1000.Visibility = Visibility.Hidden;
                btnAddExp250.Visibility = Visibility.Hidden;
            }
            try
            {
                if (int.Parse(txtConstitution.Text) >= unitLst[x].MaxCons)
                {
                    txtConstitution.Text = unitLst[x].MaxCons.ToString();
                }
                if (int.Parse(txtDexterity.Text) >= unitLst[x].MaxDex)
                {
                    txtDexterity.Text = unitLst[x].MaxDex.ToString();
                }
                if (int.Parse(txtIntelegence.Text) >= unitLst[x].MaxIntel)
                {
                    txtIntelegence.Text = unitLst[x].MaxIntel.ToString();
                }
                if (int.Parse(txtStrength.Text) >= unitLst[x].MaxStr)
                {
                    txtStrength.Text = unitLst[x].MaxStr.ToString();
                }
            }
            catch { }
        }

        private bool Check()
        {
            try
            {
                if (int.Parse(txtConstitution.Text) >= unitLst[x].MaxCons && int.Parse(txtDexterity.Text) >= unitLst[x].MaxDex && int.Parse(txtIntelegence.Text) >= unitLst[x].MaxIntel && int.Parse(txtStrength.Text) >= unitLst[x].MaxStr)
                    return true;
            }
            catch
            {
                throw new Exception("Стата достигла максимального кол-ва");
            }

            return false;
        }

        private void btnAddExp1000_Click(object sender, RoutedEventArgs e)
        {
            GetExp(5000);
            Update();
        }

        private void btnAddExp250_Click(object sender, RoutedEventArgs e)
        {
            GetExp(1000);
            Update();
        }

        private void btnAddExp500_Click(object sender, RoutedEventArgs e)
        {
            GetExp(3000);
            Update();
        }

    }
}